#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "defines.h"



void prenota_spettacolo(MYSQL *conn){

	MYSQL_STMT *prepared_stmt;
	int status;
	MYSQL_BIND param[6];

	// Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt,"call visualizza_spettacoli_prenotabili()",conn)){
		finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize movie shows list\n",false);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt)!=0){
		print_stmt_error(prepared_stmt,"Unable to load list of movie shows\n");
		
	}
	printf("\033[2J\033[H");

	do{

		if(conn->server_status & SERVER_PS_OUT_PARAMS){
			goto next;
		}

		
		dump_result_set(conn,prepared_stmt,"\nMovie shows available: ");
		

	next:
		status = mysql_stmt_next_result(prepared_stmt);
		if (status > 0){		// > 0 error, 0 keep looking, -1 finished
			finish_with_stmt_error(conn, prepared_stmt, "Unexpected condition", true);
		}
	    }while(status == 0);

	mysql_stmt_close(prepared_stmt);


	////////////
	
	// Input for the registration routine
	char codice_spettacolo[46];
	int spettacolo_ID;

	// Get the required information
	printf("\nEnter the ID of movie show that you want to book: ");
	getInput(46,codice_spettacolo,false);

	// Convert values
	spettacolo_ID = atoi(codice_spettacolo);

	// Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt,"call visualizza_posti_disponibili_per_spettacolo(?)",conn)){
		finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize 'visualizza_posti_disponibili_per_spettacolo' stmt\n",false);
	}

	// Prepare parameters
	memset(param,0,sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &spettacolo_ID;
	param[0].buffer_length = sizeof(spettacolo_ID);

	if(mysql_stmt_bind_param(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for 'visualizza_posti_disponibili_per_spettacolo' procedure\n", true);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt)!=0){
		print_stmt_error(prepared_stmt,"Unable to load list of seats available.\n");
	}
	printf("\033[2J\033[H");

	do{

		if(conn->server_status & SERVER_PS_OUT_PARAMS){
			goto next2;
		}

		
		dump_result_set(conn,prepared_stmt,"\nFree places: ");
		

	next2:
		status = mysql_stmt_next_result(prepared_stmt);
		if (status > 0){		// > 0 error, 0 keep looking, -1 finished
			finish_with_stmt_error(conn, prepared_stmt, "Unexpected condition", true);
		}
	    }while(status == 0);

	mysql_stmt_close(prepared_stmt);

	////////
	char lettera_posto;
	char numero_posto[3];
	signed char nr_posto;
	int codice_prenotazione;

	printf("\nEnter the seat number: ");
	getInput(3,numero_posto,false);

	printf("\nEnter the row letter: ");
	getInput(1,&lettera_posto,false);

	nr_posto= atoi(numero_posto);

	if(!setup_prepared_stmt(&prepared_stmt,"call prenota_spettacolo(?,?,?,?,?)",conn)){
		finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize booking list\n",false);
	}

	memset(param,0,sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = conf.username;
	param[0].buffer_length = strlen(conf.username);

	param[1].buffer_type = MYSQL_TYPE_LONG;
	param[1].buffer = &spettacolo_ID;
	param[1].buffer_length = sizeof(spettacolo_ID);

	param[2].buffer_type = MYSQL_TYPE_TINY;
	param[2].buffer = &nr_posto;
	param[2].buffer_length = sizeof(nr_posto);

	param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[3].buffer = &lettera_posto;
	param[3].buffer_length = sizeof(char);


	param[4].buffer_type = MYSQL_TYPE_LONG;  //out
	param[4].buffer = &codice_prenotazione;        //out
	param[4].buffer_length = sizeof(codice_prenotazione); ///out
	
	

	if(mysql_stmt_bind_param(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for 'prenota_spettacolo' procedure\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0){
		print_stmt_error(prepared_stmt, "An error occurred during the operation");
		goto out;
	}else{
		printf("\nTemporarily booked.\n");
	}

	// Get back the ID 

	memset(param,0,sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;  //out
	param[0].buffer = &codice_prenotazione;        //out
	param[0].buffer_length = sizeof(codice_prenotazione);

	if(mysql_stmt_bind_result(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrive output parameter\n", true);
	}
    
    // Retrieve output parameter
	if(mysql_stmt_fetch(prepared_stmt)){
		finish_with_stmt_error(conn,prepared_stmt,"Could not buffer result",true);
	}

	printf("booking id: %d",codice_prenotazione);

out: 
	mysql_stmt_close(prepared_stmt);

	////////

	char numero_carta[46];
	char intestatario_carta[46];
	char cvv[4];
	char data_scadenza[20];
	short int codice_cvv;
	long long int nr_carta;

	printf("\033[2J\033[H");

	printf ("\nEnter your credit card details.\n");

	printf("\nCredit card number: ");
	getInput(46,numero_carta,false);

	printf("\nName holder: ");
	getInput(46,intestatario_carta,false);

	printf("\nExpiry date: ");
	getInput(20,data_scadenza,false);

	printf("\nCVV code: ");
	getInput(4,cvv,false);

	codice_cvv = atoi(cvv);
	nr_carta = strtoll(numero_carta,NULL,10);
 
 	if(!setup_prepared_stmt(&prepared_stmt,"call inserisci_carta_di_credito(?,?,?,?,?,?)",conn)){
			finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize 'inserisci_carta_di_credito' stmt.\n",false);
		}
	memset(param,0,sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;  
	param[0].buffer = &codice_prenotazione;        
	param[0].buffer_length = sizeof(codice_prenotazione);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = conf.username;
	param[1].buffer_length = strlen(conf.username);

	param[2].buffer_type = MYSQL_TYPE_LONGLONG; //numero carta
	param[2].buffer = &nr_carta;
	param[2].buffer_length = sizeof(nr_carta);

	param[3].buffer_type = MYSQL_TYPE_VAR_STRING; //intest
	param[3].buffer = &intestatario_carta;
	param[3].buffer_length = strlen(intestatario_carta);

	param[4].buffer_type = MYSQL_TYPE_VAR_STRING; //data
	param[4].buffer = &data_scadenza;
	param[4].buffer_length = strlen(data_scadenza);

	param[5].buffer_type = MYSQL_TYPE_SHORT;
	param[5].buffer = &codice_cvv;
	param[5].buffer_length = sizeof(codice_cvv);

	if(mysql_stmt_bind_param(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for 'inserisci_carta_di_credito' procedure\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0){
		print_stmt_error(prepared_stmt, "An error occurred during the operation");
	}else{
		printf("\nThe card details are entered correctly.\n");
	}
    
    printf("The booking code is: %d. Save it, you’ll need it to access the cinema!!",codice_prenotazione);

    mysql_stmt_close(prepared_stmt);
}


void annulla_prenotazione(MYSQL *conn){

	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[1];
	int status;

	if(!setup_prepared_stmt(&prepared_stmt,"call visualizza_prenotazioni_attive(?)",conn)){
			finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize active bookings list.\n",false);
		}

	memset(param,0,sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = conf.username;
	param[0].buffer_length = strlen(conf.username);

	if(mysql_stmt_bind_param(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for 'visualizza_prenotazioni_attive' procedure\n", true);
	}
	
	if (mysql_stmt_execute(prepared_stmt)!=0){
	
		print_stmt_error(prepared_stmt,"Unable to load active bookings list.\n");
	}
	printf("\033[2J\033[H");

	do{

		if(conn->server_status & SERVER_PS_OUT_PARAMS){
			goto next;
		}

		
		dump_result_set(conn,prepared_stmt,"\nActive bookings: ");
		

	next:
		status = mysql_stmt_next_result(prepared_stmt);
		if (status > 0){		// > 0 error, 0 keep looking, -1 finished
			finish_with_stmt_error(conn, prepared_stmt, "Unexpected condition", true);
		}
	    }while(status == 0);

	mysql_stmt_close(prepared_stmt);


	
	//start routine annulla_prenotazione

	char c_prenotazione[46];
	int prenotazione_ID;

	printf("\nEnter the booking code you want to cancel: ");
	getInput(46,c_prenotazione,false);

	prenotazione_ID = atoi(c_prenotazione);

	if(!setup_prepared_stmt(&prepared_stmt, "call annulla_prenotazione(?)", conn)){
		finish_with_stmt_error(conn, prepared_stmt, "Unable to init 'annulla_prenotazione' stmt\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &prenotazione_ID;
	param[0].buffer_length = sizeof(prenotazione_ID);

	if(mysql_stmt_bind_param(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for 'annulla_prenotazione' procedure\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0){
		print_stmt_error(prepared_stmt, "An error occurred during the operation");
	} else{
		printf("\nThe booking has been successfully cancelled.\n");
	}

	mysql_stmt_close(prepared_stmt);

}



void run_as_customer(MYSQL *conn)
{
	char options[3] = {'1','2','3'};
	char op;
	
	printf("Switching to customer role...\n");

	if(!parse_config("/home/marina/Desktop/progetto_BD/client/cliente.json", &conf)) { 
		fprintf(stderr, "Unable to load customer configuration\n");
		exit(EXIT_FAILURE);
	}

	if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed\n");
		exit(EXIT_FAILURE);
	}
	
/* ENTRO NEL CICLO AVENDO I PRIVILEGGI QUINDI DEVO METTERE QUELLO CHE IL CUSTOMER PUO FARE (I PRIVILEGGI)*/
	while(true) {
		printf("\033[2J\033[H"); // serve per il clear screen per cancellare tutto quello che c'era sullo schermo
		printf("*** What should I do for you? ***\n\n");
		
		//DA CAMBIARE LE OPZIONI
		printf("1) Book a movie show\n");
		printf("2) Cancel booking\n");
		printf("3) Quit\n");

		op = multiChoice("Select an option", options, 3); //multichoice sta in inout.c

		switch(op) {
			case '1':
				prenota_spettacolo(conn);
				break;
			
			case '2':
				annulla_prenotazione(conn);
				break;
			
			case '3':
				return;
				
			default:
				fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
				abort();
		}

		getchar();
	}
}
