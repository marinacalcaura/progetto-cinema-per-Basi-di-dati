#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"

static void registration(MYSQL *conn){

	MYSQL_STMT *prep_stmt;
	MYSQL_BIND param[3];
	char local_options[3] = {'1', '2', '3' }; // possible roles
	char r;

	// input
	char username[46];
	char password[46];
	char var_ruolo[46];

	// get required info
	printf("\033[2J\033[H");
	printf("\nUsername: ");
	getInput(46, username, false);
	printf("Password: ");
	getInput(46, password, true);

	printf("Assign a role. Possible options are:\n");
	printf("\t1) Administrator\n");
	printf("\t2) Customer\n");
	printf("\t3) Mask\n");

	r = multiChoice("Select role", local_options, 3);
	// convert role into enum value
	switch(r){
		case '1':
			strcpy(var_ruolo, "amministratore");
			break;

		case '2':
			strcpy(var_ruolo, "cliente");
			break;

		case '3':
			strcpy(var_ruolo, "maschera");
			break;

		default:
			fprintf(stderr, "Invalid condition at %s: %d\n", __FILE__, __LINE__);
			abort();
	}

	// prepare stmt
	if(!setup_prepared_stmt(&prep_stmt, "call crea_utente(?, ?, ?)", conn)){
		finish_with_stmt_error(conn, prep_stmt, "Unable to init registration stmt\n", false);
	}

	// prepare input params
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = username;
	param[0].buffer_length = strlen(username);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = password;
	param[1].buffer_length = strlen(password);

	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = var_ruolo;
	param[2].buffer_length = strlen(var_ruolo);

	// bind params
	if(mysql_stmt_bind_param(prep_stmt, param) != 0){
		finish_with_stmt_error(conn, prep_stmt, "Could not bind parameters for registration procedure.\n", true);
	}

	// run procedure
	if (mysql_stmt_execute(prep_stmt) != 0){
		print_stmt_error(prep_stmt, "An error occurred during registration.");
		goto close;
	} else{
		printf("\n\nThe new user has been created successfully.\n");
	}

	// closing stmt
close:
	mysql_stmt_close(prep_stmt);
}



static void add_movie(MYSQL *conn){

	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[5];

	//Input for the registration routine

	char nome_film[46];
	char casa_cinematografica[46];
	char durata[3];
	short int durata_int;
	char cast_artistico[200];
	int codice_film;

	//Get the required information
	printf("\033[2J\033[H");
	printf("\nEnter the name of the movie: ");
	getInput(46,nome_film,false);

	printf("\nEnter the production company: ");
	getInput(46,casa_cinematografica,false);

	printf("\nEnter the running time [in minutes]: ");
	getInput(3,durata,false);

	printf("\nEnter the artistic cast [format:'name surname,name surname,...']: ");
	getInput(200,cast_artistico,false);

	// Convert values
	durata_int = atoi(durata);

	// Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt,"call inserisci_film(?,?,?,?,?)",conn)){
		finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize movie insertion statement\n",false);
	}

	// Prepare parameters
	memset(param,0,sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = &nome_film;
	param[0].buffer_length = strlen(nome_film);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = casa_cinematografica;
	param[1].buffer_length = strlen(casa_cinematografica);

	param[2].buffer_type = MYSQL_TYPE_SHORT;
	param[2].buffer = &durata_int;
	param[2].buffer_length = sizeof(durata_int);

	param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[3].buffer = &cast_artistico;
	param[3].buffer_length = strlen(cast_artistico);

	param[4].buffer_type = MYSQL_TYPE_LONG;
	param[4].buffer = &codice_film;
	param[4].buffer_length = sizeof(codice_film);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for movie insertion.\n", true);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while adding the movie.");
		goto out;
	} 
	// Get back the movie ID

	memset(param,0,sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;  //out
	param[0].buffer = &codice_film;        //out
	param[0].buffer_length = sizeof(codice_film);

	if(mysql_stmt_bind_result(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrive output parameter\n", true);
	}
    
    // Retrieve output parameter
	if(mysql_stmt_fetch(prepared_stmt)){
		finish_with_stmt_error(conn,prepared_stmt,"Could not buffer result",true);
	}

	printf("\n\nMovie correctly added with id: %d.\n",codice_film);

out: 
	mysql_stmt_close(prepared_stmt);

}


static void add_spectacle(MYSQL *conn){
	// visualizza prezzo-sala, aggiungi spettacolo
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[6];
	int status;

	// Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt,"call visualizza_prezzo_orario_sala()",conn)){
		finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize price list statement\n",false);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt)!=0){
		print_stmt_error(prepared_stmt,"Unable to load price list\n");
		goto out;
	}

	printf("\033[2J\033[H");

	do{

		if(conn->server_status & SERVER_PS_OUT_PARAMS){
			goto next;
		}

		
		dump_result_set(conn,prepared_stmt,"\nPrice list:\n");
		

	next:
		status = mysql_stmt_next_result(prepared_stmt);
		if (status > 0){		// > 0 error, 0 keep looking, -1 finished
			finish_with_stmt_error(conn, prepared_stmt, "Unexpected condition", true);
		}
	    }while(status == 0);
out:

	mysql_stmt_close(prepared_stmt);


	
	//start routine inserisci_spettacolo

	//Input for the registration routine
	char data_spettacolo[46];
	char ora_spettacolo[46];
	char film[46];
	int film_int;
	char sala[2];
	int sala_int;
	char cinema[46];
	int codice_spettacolo;

	//Get the required information
	printf("\nEnter the date of the movie show: ");
	getInput(46,data_spettacolo,false);

	printf("\nEnter the time of the movie show: ");
	getInput(46,ora_spettacolo,false);

	printf("\nEnter the movie ID: ");
	getInput(46,film,false);

	printf("\nEnter the movie room: ");
	getInput(2,sala,false);

	printf("\nEnter the cinema: ");
	getInput(46,cinema,false);

	// Convert values
	film_int = atoi(film);
	sala_int = atoi(sala);

	// Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt,"call inserisci_spettacolo(?,?,?,?,?,?)",conn)){
		finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize movie-show insertion statement\n",false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = &data_spettacolo;
	param[0].buffer_length = strlen(data_spettacolo);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = &ora_spettacolo;
	param[1].buffer_length = strlen(ora_spettacolo);

	param[2].buffer_type = MYSQL_TYPE_LONG;
	param[2].buffer = &film_int;
	param[2].buffer_length = sizeof(film_int);

	param[3].buffer_type = MYSQL_TYPE_LONG;
	param[3].buffer = &sala_int;
	param[3].buffer_length = sizeof(sala_int);

	param[4].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[4].buffer = &cinema;
	param[4].buffer_length = strlen(cinema);

	param[5].buffer_type = MYSQL_TYPE_LONG;                //out
	param[5].buffer = &codice_spettacolo;                  //out
	param[5].buffer_length = sizeof(codice_spettacolo);    //out

	if(mysql_stmt_bind_param(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for movie-show insertion\n", true);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while adding the movie-show.");
	}else{
		printf("\nSpectacle correctly added.\n");
	} 
	
	mysql_stmt_close(prepared_stmt);

}

static void add_employee(MYSQL *conn){

	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[5];

	//Input for the registration routine

	char matricola[20];
	char nome[46];
	char cognome[46];
	char tipo[15];
	char cinema[20];

	//Get the required information
	printf("\033[2J\033[H");

	printf("\nEnter employee ID: ");
	getInput(20,matricola,false);

	printf("\nEnter the employee's name: ");
	getInput(46,nome,false);

	printf("\nEnter the employee's surname: ");
	getInput(26,cognome,false);

	printf("\nEnter the type of employee [maschera/proiezionista]: ");
	getInput(15,tipo,false);

	printf("\nEnter the cinema: ");
	getInput(20,cinema,false);

	// Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt,"call inserisci_dipendente(?,?,?,?,?)",conn)){
		finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize employee insertion statement\n",false);
	}

	// Prepare parameters
	memset(param,0,sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = &matricola;
	param[0].buffer_length = strlen(matricola);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer =&nome;
	param[1].buffer_length = strlen(nome);

	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = &cognome;
	param[2].buffer_length = strlen(cognome);

	param[3].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[3].buffer = &tipo;
	param[3].buffer_length = strlen(tipo);

	param[4].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[4].buffer = &cinema;
	param[4].buffer_length = strlen(cinema);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for employee insertion.\n", true);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while adding the employee.");
	} else{
		printf("\n\nEmployee correctly added.\n");
	}
	mysql_stmt_close(prepared_stmt);

}

static void add_work_shift(MYSQL *conn){

	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[4];

	//Input for the registration routine

	char data_turno[20];
	char orario_inizio[10];
	char orario_fine[10];
	int codice_turno;

	//Get the required information
	printf("\033[2J\033[H");
	printf("\nEnter the date of the work shift: ");
	getInput(20,data_turno,false);

	printf("\nEnter the start time: ");
	getInput(10,orario_inizio,false);

	printf("\nEnter the end time: ");
	getInput(10,orario_fine,false);

	// Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt,"call registra_turno_di_lavoro(?,?,?,?)",conn)){
		finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize work shift insertion statement\n",false);
	}

	// Prepare parameters
	memset(param,0,sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = &data_turno;
	param[0].buffer_length = strlen(data_turno);

	param[1].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[1].buffer = orario_inizio;
	param[1].buffer_length = strlen(orario_inizio);

	param[2].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[2].buffer = &orario_fine;
	param[2].buffer_length = strlen(orario_fine);

	param[3].buffer_type = MYSQL_TYPE_LONG;
	param[3].buffer = &codice_turno;
	param[3].buffer_length = sizeof(codice_turno);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for work shift insertion.\n", true);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error (prepared_stmt, "An error occurred while adding the shift.");
		goto out;
	} 
	// Get back the shift ID

	memset(param,0,sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;  //out
	param[0].buffer = &codice_turno;        //out
	param[0].buffer_length = sizeof(codice_turno);

	if(mysql_stmt_bind_result(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrive output parameter\n", true);
	}
    
    // Retrieve output parameter
	if(mysql_stmt_fetch(prepared_stmt)){
		finish_with_stmt_error(conn,prepared_stmt,"Could not buffer result",true);
	}

	printf("\nWork shift correctly added with id: %d.",codice_turno);

out: 
	mysql_stmt_close(prepared_stmt);

}


static void assign_work_shift(MYSQL *conn){

	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[2];
	int status;

	if(!setup_prepared_stmt(&prepared_stmt,"call visualizza_dipendenti()",conn)){
			finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize employees list statement\n",false);
		}

	
	if (mysql_stmt_execute(prepared_stmt)!=0){
	
		print_stmt_error(prepared_stmt,"Unable to load list of employees\n");

	}

	printf("\033[2J\033[H");

	do{

		if(conn->server_status & SERVER_PS_OUT_PARAMS){
			goto next;
		}

		
		dump_result_set(conn,prepared_stmt,"\nEmployees:\n");
		

	next:
		status = mysql_stmt_next_result(prepared_stmt);
		if (status > 0){		// > 0 error, 0 keep looking, -1 finished
			finish_with_stmt_error(conn, prepared_stmt, "Unexpected condition", true);
		}
	    }while(status == 0);

	mysql_stmt_close(prepared_stmt);


	
	//start routine assegna turno di lavoro

	char matricola[20];
	char turno[46];
	int turno_int;

	printf("\nEnter the employee ID: ");
	getInput(20,matricola,false);

	printf("\nEnter the work shift ID: ");
	getInput(46,turno,false);

	turno_int = atoi(turno);

	if(!setup_prepared_stmt(&prepared_stmt, "call assegna_turno_di_lavoro(?,?)", conn)){
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize 'assegna_turno_di_lavoro' stmt\n", false);
	}

	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = &matricola;
	param[0].buffer_length = strlen(matricola);

	param[1].buffer_type = MYSQL_TYPE_LONG;
	param[1].buffer = &turno_int;
	param[1].buffer_length = sizeof(turno_int);

	if(mysql_stmt_bind_param(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for 'assegna_turno_di_lavoro' procedure\n", true);
	}

	if (mysql_stmt_execute(prepared_stmt) != 0){
		print_stmt_error(prepared_stmt, "An error occurred during the operation");
	} else{
		printf("\n\nThe work shift has been successfully assigned.\n");
	}

	mysql_stmt_close(prepared_stmt);

}


static void shift_report(MYSQL *conn){

	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[1];
	int status;

	char nr_settimana[3];
	int settimana_int;

	printf("\nEnter the week number: ");
	getInput(3,nr_settimana,false);

	settimana_int = atoi(nr_settimana);

	//prepared stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt,"call report_settimanale_turni(?)",conn)){
			finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize work shifts report stmt\n",false);
		}
	//prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_LONG;
	param[0].buffer = &settimana_int;
	param[0].buffer_length = sizeof(settimana_int);

	if(mysql_stmt_bind_param(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for work shifts report\n", true);
	}
	
	//run procedure
	if (mysql_stmt_execute(prepared_stmt)!=0){
	
		print_stmt_error(prepared_stmt,"Unable to load list of work shift\n");
	}

	printf("\nCinema that in some time slot are deprived of at least two masks and movie show ID without projectionist: \n");

	do{

		if(conn->server_status & SERVER_PS_OUT_PARAMS){
			goto next;
		}

		
		dump_result_set(conn,prepared_stmt,"");
		

	next:
		status = mysql_stmt_next_result(prepared_stmt);
		if (status > 0){		// > 0 error, 0 keep looking, -1 finished
			finish_with_stmt_error(conn, prepared_stmt, "Unexpected condition", true);
		}
	    }while(status == 0);

	mysql_stmt_close(prepared_stmt);
}

static void manage_employees(MYSQL *conn){

	char options[5] = {'1','2', '3', '4', '5'};
	char op;

	while(true) {
		printf("\033[2J\033[H");
		printf("1) Insert employee\n");
		printf("2) Insert work shift\n");
		printf("3) Assign work shift\n");
		printf("4) Work shift report\n");
		printf("5) Quit\n");

		op = multiChoice("Select an option", options, 5);

		switch(op) {
			case '1':
				add_employee(conn);
				break;
			case '2':
				add_work_shift(conn);
				break;
			case '3':
				assign_work_shift(conn);
				break;
			case '4':
				shift_report(conn);
				break;
			case '5':
				return;
				
			default:
				fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
				abort();
		}

		getchar();
	}

}

static void booking_report(MYSQL *conn){

	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[1];
	int status;

	char mese[2];
	short int mese_int;

	printf("\033[2J\033[H");

	printf("\nEnter the month number: ");
	getInput(2,mese,false);

	mese_int = strtol(mese,NULL,10);

	//prepared stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt,"call report_mensile_prenotazioni(?)",conn)){
			finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize booking report statement\n",false);
		}
	//prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_SHORT;
	param[0].buffer = &mese_int;
	param[0].buffer_length = sizeof(mese_int);

	if(mysql_stmt_bind_param(prepared_stmt, param) != 0){
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for booking report\n", true);
	}
	
	//run procedure
	if (mysql_stmt_execute(prepared_stmt)!=0){
	
		print_stmt_error(prepared_stmt,"Unable to load booking report\n");
	}
	do{

		if(conn->server_status & SERVER_PS_OUT_PARAMS){
			goto next;
		}

		
		dump_result_set(conn,prepared_stmt,"");
		

	next:
		status = mysql_stmt_next_result(prepared_stmt);
		if (status > 0){		// > 0 error, 0 keep looking, -1 finished
			finish_with_stmt_error(conn, prepared_stmt, "Unexpected condition", true);
		}
	    }while(status == 0);

	
	mysql_stmt_close(prepared_stmt);
}


static void add_customer(MYSQL *conn)
{
	MYSQL_STMT *prepared_stmt;
	MYSQL_BIND param[2];

	// Input for the registration routine
	
	char username[46];
	int codice_cliente;

	// Get the required information
	printf("\033[2J\033[H");
	printf("Customer username: ");
	getInput(46, username, false);

	// Prepare stored procedure call
	if(!setup_prepared_stmt(&prepared_stmt, "call aggiungi_cliente(?, ?)", conn)) {
		finish_with_stmt_error(conn, prepared_stmt, "Unable to initialize customer insertion statement\n", false);
	}

	// Prepare parameters
	memset(param, 0, sizeof(param));

	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = username;
	param[0].buffer_length = strlen(username);

	param[1].buffer_type = MYSQL_TYPE_LONG; // OUT
	param[1].buffer = &codice_cliente;
	param[1].buffer_length = sizeof(codice_cliente);

	if (mysql_stmt_bind_param(prepared_stmt, param) != 0) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not bind parameters for customer insertion\n", true);
	}

	// Run procedure
	if (mysql_stmt_execute(prepared_stmt) != 0) {
		print_stmt_error(prepared_stmt, "An error occurred while adding the customer.");
		goto out;
	}

	// Get back the ID of the newly-added customer
	memset(param, 0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_LONG; // OUT
	param[0].buffer = &codice_cliente;
	param[0].buffer_length = sizeof(codice_cliente);
	
	if(mysql_stmt_bind_result(prepared_stmt, param)) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not retrieve output parameter", true);
	}
	
	// Retrieve output parameter
	if(mysql_stmt_fetch(prepared_stmt)) {
		finish_with_stmt_error(conn, prepared_stmt, "Could not buffer results", true);
	}

	printf("\n\nCustomer correctly added with ID %d.\n", codice_cliente);

    out:
	mysql_stmt_close(prepared_stmt);
}

void run_as_administrator(MYSQL *conn)
{
	char options[7] = {'1','2', '3', '4', '5','6','7'};
	char op;
	
	printf("Switching to administrative role...\n");

	if(!parse_config("/home/marina/Desktop/progetto_BD/client/amministratore.json", &conf)) {
		fprintf(stderr, "Unable to load administrator configuration\n");
		exit(EXIT_FAILURE);
	}

	if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed\n");
		exit(EXIT_FAILURE);
	}

	while(true) {
		printf("\033[2J\033[H");
		printf("*** What should I do for you? ***\n\n");
		printf("1) Create new user\n");
		printf("2) Add customer \n");
		printf("3) Insert movie \n");
		printf("4) Insert movie show\n");
		printf("5) Manage the work shifts\n");
		printf("6) Booking reports\n");
		printf("7) Quit\n");

		op = multiChoice("Select an option", options, 7);

		switch(op) {
			case '1':
				registration(conn);
				break;
			case '2':
				add_customer(conn);
				break;
			case '3':
				add_movie(conn);
				break;
			case '4':
				add_spectacle(conn);
				break;
			case '5':
				manage_employees(conn);
				break;
			case '6':
				booking_report(conn);
				break;
			case '7':
				return;
				
			default:
				fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
				abort();
		}

		getchar();
	}
}
