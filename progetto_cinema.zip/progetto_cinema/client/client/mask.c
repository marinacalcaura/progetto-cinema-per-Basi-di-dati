#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "defines.h"

void verifica_prenotazione(MYSQL *conn){

	MYSQL_BIND param[1];
	MYSQL_STMT *prepared_stmt;

	char code[46];
	printf("\033[2J\033[H");
	printf("Enter the costumer's code: ");
	getInput(45,code,false);

	if(!setup_prepared_stmt(&prepared_stmt,"call verifica_prenotazione(?)",conn)){
		finish_with_stmt_error(conn,prepared_stmt,"Unable to initialize the booking verification statement\n",false);
	}

	memset(param,0, sizeof(param));
	param[0].buffer_type = MYSQL_TYPE_VAR_STRING;
	param[0].buffer = code;
	param[0].buffer_length = strlen(code);

	if(mysql_stmt_bind_param(prepared_stmt,param)!=0){
		finish_with_stmt_error(conn,prepared_stmt,"Could not bind parameters for booking verification\n",true);
	}


	if (mysql_stmt_execute(prepared_stmt)!=0){
	
		print_stmt_error(prepared_stmt,"An error occured while validated the code\n");
	} else{
		printf("The code's validation was successful.\n");
	}

	mysql_stmt_close(prepared_stmt);


}


void run_as_mask(MYSQL *conn)
{
	char options[2] = {'1','2'};
	char op;
	
	printf("Switching to professor role...\n");

	if(!parse_config("/home/marina/Desktop/progetto_BD/client/maschera.json", &conf)) {
		fprintf(stderr, "Unable to load professor configuration\n");
		exit(EXIT_FAILURE);
	}

	if(mysql_change_user(conn, conf.db_username, conf.db_password, conf.database)) {
		fprintf(stderr, "mysql_change_user() failed\n");
		exit(EXIT_FAILURE);
	}

	while(true) {
		printf("\033[2J\033[H");
		printf("*** What should I do for you? ***\n\n");
		printf("1) Booking verification\n");
		printf("2) Quit\n");

		op = multiChoice("Select an option", options, 2);

		switch(op) {
			case '1':
				verifica_prenotazione(conn);
				break;
				
			case '2':
				return;
				
			default:
				fprintf(stderr, "Invalid condition at %s:%d\n", __FILE__, __LINE__);
				abort();
		}
		

		getchar();
	}
}
