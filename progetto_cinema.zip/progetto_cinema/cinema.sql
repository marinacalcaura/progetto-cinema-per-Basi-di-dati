-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema Gestione_cinema
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `Gestione_cinema` ;

-- -----------------------------------------------------
-- Schema Gestione_cinema
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Gestione_cinema` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `Gestione_cinema` ;

-- -----------------------------------------------------
-- Table `Gestione_cinema`.`utenti`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`utenti` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`utenti` (
  `username` VARCHAR(45) NOT NULL,
  `password` CHAR(32) NOT NULL,
  `ruolo` ENUM('cliente', 'maschera', 'amministratore') NOT NULL,
  PRIMARY KEY (`username`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`cliente`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`cliente` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`cliente` (
  `codice_cliente` INT NOT NULL AUTO_INCREMENT,
  `username_cliente` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`codice_cliente`),
  CONSTRAINT `fk_cliente_1`
    FOREIGN KEY (`username_cliente`)
    REFERENCES `Gestione_cinema`.`utenti` (`username`))
ENGINE = InnoDB
AUTO_INCREMENT = 10
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

CREATE UNIQUE INDEX `username_cliente_UNIQUE` ON `Gestione_cinema`.`cliente` (`username_cliente` ASC) VISIBLE;

CREATE INDEX `fk_cliente_1_idx` ON `Gestione_cinema`.`cliente` (`username_cliente` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`carta_di_credito`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`carta_di_credito` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`carta_di_credito` (
  `numero_carta` BIGINT NOT NULL,
  `cliente` INT NOT NULL,
  `nome_intestatario` VARCHAR(45) NOT NULL,
  `data_scadenza_carta` DATE NOT NULL,
  `cvv` SMALLINT NOT NULL,
  PRIMARY KEY (`numero_carta`),
  CONSTRAINT `fk_carta_di_credito_1`
    FOREIGN KEY (`cliente`)
    REFERENCES `Gestione_cinema`.`cliente` (`codice_cliente`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

CREATE INDEX `fk_carta_di_credito_1_idx` ON `Gestione_cinema`.`carta_di_credito` (`cliente` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`film`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`film` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`film` (
  `codice_film` INT NOT NULL AUTO_INCREMENT,
  `nome_film` VARCHAR(45) NOT NULL,
  `casa_cinematografica` VARCHAR(45) NOT NULL,
  `durata` SMALLINT NOT NULL,
  PRIMARY KEY (`codice_film`))
ENGINE = InnoDB
AUTO_INCREMENT = 10
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`cast_artistico`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`cast_artistico` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`cast_artistico` (
  `nome_attore` VARCHAR(45) NOT NULL,
  `cognome_attore` VARCHAR(45) NOT NULL,
  `film` INT NOT NULL,
  PRIMARY KEY (`nome_attore`, `cognome_attore`, `film`),
  CONSTRAINT `fk_cast_artistico_1`
    FOREIGN KEY (`film`)
    REFERENCES `Gestione_cinema`.`film` (`codice_film`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

CREATE INDEX `fk_cast_artistico_1_idx` ON `Gestione_cinema`.`cast_artistico` (`film` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`cinema`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`cinema` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`cinema` (
  `nome_cinema` VARCHAR(45) NOT NULL,
  `orario_apertura` TIME NOT NULL,
  `orario_chiusura` TIME NOT NULL,
  PRIMARY KEY (`nome_cinema`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`dipendente`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`dipendente` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`dipendente` (
  `matricola_dipendente` VARCHAR(45) NOT NULL,
  `nome_dipendente` VARCHAR(45) NOT NULL,
  `cognome_dipendente` VARCHAR(45) NOT NULL,
  `tipo` ENUM('maschera', 'proiezionista') NOT NULL,
  `cinema` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`matricola_dipendente`),
  CONSTRAINT `fk_dipendente_1`
    FOREIGN KEY (`cinema`)
    REFERENCES `Gestione_cinema`.`cinema` (`nome_cinema`)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

CREATE INDEX `fk_dipendente_1_idx` ON `Gestione_cinema`.`dipendente` (`cinema` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`posto`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`posto` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`posto` (
  `numero_posto` TINYINT NOT NULL,
  `fila` CHAR(1) NOT NULL,
  `sala` TINYINT NOT NULL,
  `cinema` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`numero_posto`, `fila`, `sala`, `cinema`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

CREATE INDEX `fk_posto_1_idx` ON `Gestione_cinema`.`posto` (`sala` ASC, `cinema` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`prezzo_spettacolo`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`prezzo_spettacolo` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`prezzo_spettacolo` (
  `sala_prezzo` INT NOT NULL,
  `ora_prezzo` TIME NOT NULL,
  `prezzo` FLOAT NOT NULL,
  PRIMARY KEY (`sala_prezzo`, `ora_prezzo`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`spettacolo`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`spettacolo` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`spettacolo` (
  `codice_spettacolo` INT NOT NULL AUTO_INCREMENT,
  `data_spettacolo` DATE NOT NULL,
  `ora_spettacolo` TIME NOT NULL,
  `film` INT NOT NULL,
  `sala_spettacolo` INT NOT NULL,
  `cinema` VARCHAR(45) NOT NULL,
  `proiezionista` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`codice_spettacolo`),
  CONSTRAINT `fk_spettacolo_1`
    FOREIGN KEY (`sala_spettacolo` , `ora_spettacolo`)
    REFERENCES `Gestione_cinema`.`prezzo_spettacolo` (`sala_prezzo` , `ora_prezzo`)
    ON DELETE RESTRICT
    ON UPDATE CASCADE,
  CONSTRAINT `fk_spettacolo_2`
    FOREIGN KEY (`film`)
    REFERENCES `Gestione_cinema`.`film` (`codice_film`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_spettacolo_4`
    FOREIGN KEY (`proiezionista`)
    REFERENCES `Gestione_cinema`.`dipendente` (`matricola_dipendente`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 10
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

CREATE INDEX `fk_spettacolo_2_idx` ON `Gestione_cinema`.`spettacolo` (`film` ASC) VISIBLE;

CREATE INDEX `fk_spettacolo_3_idx` ON `Gestione_cinema`.`spettacolo` (`proiezionista` ASC) VISIBLE;

CREATE INDEX `fk_spettacolo_1_idx` ON `Gestione_cinema`.`spettacolo` (`sala_spettacolo` ASC, `ora_spettacolo` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`prenotazione`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`prenotazione` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`prenotazione` (
  `codice_prenotazione` INT NOT NULL AUTO_INCREMENT,
  `data_prenotazione` DATE NOT NULL,
  `ora_prenotazione` TIME NOT NULL,
  `esito` ENUM('in processamento', 'utilizzata', 'inutilizzata', 'annullata') NOT NULL DEFAULT 'in processamento',
  `spettacolo_prenotato` INT NOT NULL,
  `nr_posto` TINYINT NOT NULL,
  `fila_posto` CHAR(1) NOT NULL,
  `nr_sala` TINYINT NOT NULL,
  `cinema` VARCHAR(45) NOT NULL,
  `cliente_associato` INT NOT NULL,
  PRIMARY KEY (`codice_prenotazione`),
  CONSTRAINT `fk_prenotazione_1`
    FOREIGN KEY (`spettacolo_prenotato`)
    REFERENCES `Gestione_cinema`.`spettacolo` (`codice_spettacolo`)
    ON DELETE CASCADE
    ON UPDATE RESTRICT,
  CONSTRAINT `fk_prenotazione_2`
    FOREIGN KEY (`nr_posto` , `fila_posto` , `nr_sala` , `cinema`)
    REFERENCES `Gestione_cinema`.`posto` (`numero_posto` , `fila` , `sala` , `cinema`)
    ON DELETE RESTRICT,
  CONSTRAINT `fk_prenotazione_3`
    FOREIGN KEY (`cliente_associato`)
    REFERENCES `Gestione_cinema`.`cliente` (`codice_cliente`)
    ON DELETE RESTRICT)
ENGINE = InnoDB
AUTO_INCREMENT = 10
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

CREATE INDEX `fk_prenotazione_2_idx` ON `Gestione_cinema`.`prenotazione` (`spettacolo_prenotato` ASC) VISIBLE;

CREATE INDEX `fk_prenotazione_1_idx` ON `Gestione_cinema`.`prenotazione` (`nr_posto` ASC, `fila_posto` ASC, `nr_sala` ASC, `cinema` ASC) VISIBLE;

CREATE INDEX `fk_prenotazione_3_idx` ON `Gestione_cinema`.`prenotazione` (`cliente_associato` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`sala`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`sala` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`sala` (
  `numero_sala` INT NOT NULL,
  `cinema` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`numero_sala`, `cinema`),
  CONSTRAINT `fk_sala_1`
    FOREIGN KEY (`cinema`)
    REFERENCES `Gestione_cinema`.`cinema` (`nome_cinema`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

CREATE INDEX `fk_sala_1_idx` ON `Gestione_cinema`.`sala` (`cinema` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`turno_lavoro`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`turno_lavoro` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`turno_lavoro` (
  `codice_turno` INT NOT NULL AUTO_INCREMENT,
  `data_turno` DATE NOT NULL,
  `orario_inizio` TIME NOT NULL,
  `orario_fine` TIME NOT NULL,
  PRIMARY KEY (`codice_turno`))
ENGINE = InnoDB
AUTO_INCREMENT = 10
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `Gestione_cinema`.`servizio`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Gestione_cinema`.`servizio` ;

CREATE TABLE IF NOT EXISTS `Gestione_cinema`.`servizio` (
  `dipendente` VARCHAR(45) NOT NULL,
  `turno_di_lavoro` INT NOT NULL,
  `nr_settimana` MEDIUMINT NOT NULL,
  PRIMARY KEY (`dipendente`, `turno_di_lavoro`),
  CONSTRAINT `fk_servizio_1`
    FOREIGN KEY (`turno_di_lavoro`)
    REFERENCES `Gestione_cinema`.`turno_lavoro` (`codice_turno`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_servizio_2`
    FOREIGN KEY (`dipendente`)
    REFERENCES `Gestione_cinema`.`dipendente` (`matricola_dipendente`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

CREATE INDEX `fk_servizio_1_idx` ON `Gestione_cinema`.`servizio` (`turno_di_lavoro` ASC) VISIBLE;

CREATE INDEX `fk_servizio_2_idx` ON `Gestione_cinema`.`servizio` (`dipendente` ASC) VISIBLE;

USE `Gestione_cinema` ;

-- -----------------------------------------------------
-- function SPLIT_STR
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP function IF EXISTS `Gestione_cinema`.`SPLIT_STR`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE FUNCTION `SPLIT_STR`(
  x VARCHAR(255),
  delim VARCHAR(12),
  pos INT
) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
RETURN REPLACE(SUBSTRING(SUBSTRING_INDEX(x, delim, pos),
       LENGTH(SUBSTRING_INDEX(x, delim, pos -1)) + 1),
       delim, '')$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure aggiungi_cliente
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`aggiungi_cliente`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `aggiungi_cliente`(in var_username varchar(45),
                                                               out var_codice_cliente int)
BEGIN 
        insert into `cliente`(`username_cliente`,`codice_cliente`) values (var_username, var_codice_cliente);
        set var_codice_cliente = last_insert_id();
       
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure annulla_prenotazione
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`annulla_prenotazione`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `annulla_prenotazione`(in var_codice_prenotazione int)
BEGIN
	declare var_orario time;
    declare var_data date;
    
    declare exit handler for sqlexception
    begin
        rollback;  -- rollback any changes made in the transaction
        resignal;  -- raise again the sql exception to the caller
    end;
    
    set transaction isolation level repeatable read; 
	start transaction;
      
		 select data_spettacolo, ora_spettacolo 
		 from Gestione_cinema.prenotazione join Gestione_cinema.spettacolo on spettacolo_prenotato=codice_spettacolo
		 where codice_prenotazione = var_codice_prenotazione into var_data, var_orario;
		 
		 if timediff(concat(var_data,' ',var_orario),now()) >= '00:30:00' then
			update `prenotazione` set esito = 'annullata' where codice_prenotazione = var_codice_prenotazione;
		 else
			signal sqlstate '45000' set message_text = 'Non è possibile annullare la prenotazione!';
		 end if;
    
	commit;
    
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure assegna_turno_di_lavoro
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`assegna_turno_di_lavoro`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `assegna_turno_di_lavoro`(in var_matricola_dipendente varchar(45),
																	  in var_turno_servizio int)
BEGIN
		declare var_tipo_dipendente enum('maschera', 'proiezionista');
        declare var_cinema_dipendente varchar(45);
        declare var_data_turno date;
        declare var_inizio_turno time;
        declare var_fine_turno time;
        declare var_ora_spettacolo time;
        declare var_nr_settimana smallint;
		declare exit handler for sqlexception
		begin
			rollback;  -- rollback any changes made in the transaction
			resignal;  -- raise again the sql exception to the caller
		end;
        
		set transaction isolation level repeatable read;
		start transaction;
    
        select data_turno,orario_inizio,orario_fine from `turno_lavoro` 
        where codice_turno = var_turno_servizio into var_data_turno, var_inizio_turno, var_fine_turno;
        set var_nr_settimana =  week(var_data_turno);
        
        insert into `servizio`(`dipendente`,`turno_di_lavoro`,`nr_settimana`) values (var_matricola_dipendente, var_turno_servizio, var_nr_settimana);
        
        select tipo,cinema from dipendente 
        where matricola_dipendente = var_matricola_dipendente into var_tipo_dipendente,var_cinema_dipendente;
        if (var_tipo_dipendente = 'proiezionista')then
				update spettacolo set spettacolo.proiezionista = var_matricola_dipendente 
                where spettacolo.data_spettacolo= var_data_turno and (spettacolo.ora_spettacolo between var_inizio_turno and var_fine_turno) and spettacolo.cinema = var_cinema_dipendente;
		        
        end if;
        commit;
	END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure crea_utente
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`crea_utente`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `crea_utente`(IN username varchar(45),
														  IN password varchar(45),
                                                          IN ruolo ENUM('amministratore','cliente','maschera'))
BEGIN
    insert into `utenti` values (username, md5(password), ruolo);
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure inserisci_carta_di_credito
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`inserisci_carta_di_credito`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `inserisci_carta_di_credito`(in var_codice_prenotazione int,
												in var_username varchar(45),
												in var_numero_carta bigint,
												in var_nome_intestatario varchar(45),
                                                in var_data_scadenza varchar(45),
                                                in var_codice_cvv smallint
                                                )
BEGIN

   declare var_codice_cliente int;
   declare var_data date; 
   
   declare exit handler for sqlexception
    begin
        rollback;  -- rollback any changes made in the transaction
        resignal;  -- raise again the sql exception to the caller
    end;
    
	set transaction isolation level read committed;
	start transaction;
      
		select codice_cliente into var_codice_cliente
		from Gestione_cinema.cliente
		where username_cliente = var_username;
		  
		set var_data = str_to_date(var_data_scadenza,'%Y-%m-%d');
		insert into `carta_di_credito`(`numero_carta`,`cliente`,`nome_intestatario`,`data_scadenza_carta`,`cvv`) 
							values(var_numero_carta,var_codice_cliente, var_nome_intestatario, var_data, var_codice_cvv );
							
		update Gestione_cinema.prenotazione set esito="inutilizzata"
		where codice_prenotazione=var_codice_prenotazione;
    
    commit;

END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure inserisci_dipendente
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`inserisci_dipendente`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `inserisci_dipendente`( in var_matricola_dipendente varchar(45),
											in var_nome_dipendente varchar(45),
                                            in var_cognome_dipendente varchar(45),
                                            in var_tipo enum ('maschera','proiezionista'),
                                            in var_cinema varchar(45))
BEGIN
	insert into `dipendente`(`matricola_dipendente`,`nome_dipendente`,`cognome_dipendente`,`tipo`,`cinema`) 
		values (var_matricola_dipendente, var_nome_dipendente, var_cognome_dipendente, var_tipo, var_cinema);
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure inserisci_film
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`inserisci_film`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `inserisci_film`(in var_nome_film varchar(45),
									in var_casa_cinematografica varchar(45),
                                    in var_durata smallint,
                                    in list_cast_artistico varchar(200),
                                    out var_codice_film int)
BEGIN
    declare contN int default 1;
    declare contC int default 2;
    declare cont int default 1;
    declare var_nome_cognome varchar(45);
    declare var_nome_attore varchar(45);
    declare var_cognome_attore varchar(45);
    
    declare exit handler for sqlexception
      begin
        rollback;  -- rollback any changes made in the transaction
        resignal;  -- raise again the sql exception to the caller
    end;
    
    set transaction isolation level read uncommitted;
      
    start transaction; 
    insert into `film` (`nome_film`, `casa_cinematografica`,`durata`) values (var_nome_film, var_casa_cinematografica, var_durata);
    set var_codice_film = last_insert_id();
    
    insert_loop: loop  
    select SPLIT_STR(list_cast_artistico, ",", cont) into var_nome_cognome;
    if var_nome_cognome = '' then leave insert_loop;
    end if;
       select SPLIT_STR(var_nome_cognome," ",contN) into var_nome_attore;
       
       select SPLIT_STR(var_nome_cognome," ",contC) into var_cognome_attore;
       
       insert into `cast_artistico`(`nome_attore` ,`cognome_attore` ,`film` ) values (var_nome_attore, var_cognome_attore, var_codice_film);
        set cont = cont+1;
    end loop;
    commit;
    
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure inserisci_spettacolo
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`inserisci_spettacolo`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `inserisci_spettacolo`(in var_data_spettacolo varchar(45), 
                                                               in var_ora_spettacolo varchar(45),
                                                               in var_film int,
                                                               in var_sala int,
                                                               in var_cinema varchar(45),
                                                               out var_codice_spettacolo int)
BEGIN
    declare var_data date;
    declare var_ora time;
    set var_data = str_to_date(var_data_spettacolo,'%Y-%m-%d');
    set var_ora = str_to_date(var_ora_spettacolo, '%T');
    
	insert into `spettacolo` (`data_spettacolo`, `ora_spettacolo`,`film`,`sala_spettacolo`,`cinema`) values (var_data, var_ora, var_film, var_sala, var_cinema);
    
    set var_codice_spettacolo = last_insert_id();
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure login
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`login`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `login`(in var_username varchar(45), in var_password varchar(45), out var_role INT)
BEGIN
    declare var_user_role ENUM('amministratore','cliente', 'maschera');
    
    select `ruolo` from `utenti`
        where `username` = var_username
        and `password` = md5(var_password)
        into var_user_role;
        
        if var_user_role = 'amministratore' then
		    set var_role = 1;
		elseif var_user_role = 'cliente' then
		    set var_role = 2;
		elseif var_user_role = 'maschera' then
		    set var_role = 3;
		else
            set var_role = 4;
		end if;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure prenota_spettacolo
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`prenota_spettacolo`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `prenota_spettacolo`(in var_username varchar(45),
                                          in var_spettacolo int ,
										  in var_nr_posto tinyint,
                                          in var_fila char(1),
										  out var_codice_prenotazione int)
BEGIN
	
    declare var_cliente int;
    declare var_sala tinyint;
    declare var_cinema varchar(45);
    
    declare exit handler for sqlexception
    begin
        rollback;  -- rollback any changes made in the transaction
        resignal;  -- raise again the sql exception to the caller
    end;
    
    set transaction isolation level read committed; 
	start transaction; 
	
		select sala_spettacolo, cinema
		from `spettacolo` 
		where codice_spettacolo = var_spettacolo into var_sala,var_cinema;
		
		select codice_cliente 
		from cliente 
		where username_cliente = var_username into var_cliente;
		
		
		insert into `prenotazione`(`data_prenotazione`,`ora_prenotazione`,`spettacolo_prenotato`,`nr_posto`,`fila_posto`,`nr_sala`,`cinema`,`cliente_associato`) 
									 values (curdate(),curtime(), var_spettacolo, var_nr_posto, var_fila, var_sala, var_cinema, var_cliente);
									 
		set var_codice_prenotazione = last_insert_id();
    
    commit;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure registra_turno_di_lavoro
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`registra_turno_di_lavoro`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `registra_turno_di_lavoro`(in var_data_turno varchar(45),
										    in var_orario_inizio varchar(45),
											in var_orario_fine varchar(45),
										    out var_codice_turno int)
BEGIN

    declare var_data date;
    declare var_inizio time;
    declare var_fine time;
    
    set var_data = str_to_date(var_data_turno,'%Y-%m-%d');
    set var_inizio = str_to_date(var_orario_inizio, '%T');
    set var_fine = str_to_date(var_orario_fine, '%T');

	insert into `turno_lavoro`(`data_turno`, `orario_inizio`, `orario_fine`) values (var_data, var_inizio, var_fine);
	
    set var_codice_turno = last_insert_id();
    
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure report_mensile_prenotazioni
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`report_mensile_prenotazioni`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `report_mensile_prenotazioni`(in var_mese smallint)
BEGIN


	declare exit handler for sqlexception
    begin
        rollback;  -- rollback any changes made in the transaction
        resignal;  -- raise again the sql exception to the caller
    end;
    
    
    set transaction isolation level serializable; 
    start transaction;
		select p.cinema, p.nr_sala, coalesce(b.total,0) as prenot_annull, coalesce(c.total,0) as prenot_inutilizz, coalesce(d.total,0) as prenot_confermate from prenotazione p
		left outer join(select cinema, nr_sala, count(*) as total from prenotazione where esito = 'annullata' and month(data_prenotazione) = var_mese group by cinema, nr_sala) b on p.cinema = b.cinema and p.nr_sala=b.nr_sala
		left outer join (select cinema, nr_sala, count(*) as total from prenotazione where esito = 'inutilizzata' and month(data_prenotazione) = var_mese group by cinema, nr_sala) c on p.cinema = c.cinema and p.nr_sala=c.nr_sala
		left outer join (select cinema, nr_sala, count(*) as total from prenotazione where (esito = 'utilizzata' or esito = 'inutilizzata') and month(data_prenotazione) = var_mese group by cinema, nr_sala) d on p.cinema = d.cinema and p.nr_sala=d.nr_sala
		group by p.cinema, p.nr_sala;

    commit;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure report_settimanale_turni
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`report_settimanale_turni`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `report_settimanale_turni`(in var_nr_settimana int)
BEGIN
	
	declare exit handler for sqlexception
    begin
        rollback;  -- rollback any changes made in the transaction
        resignal;  -- raise again the sql exception to the caller
    end;
    
	
    set transaction isolation level serializable; 
    start transaction;
    
    
		select cinema,data_turno,orario_inizio, orario_fine, orario_apertura,orario_chiusura,count(dipendente) as maschera
		from Gestione_cinema.servizio 
		join turno_lavoro on turno_di_lavoro = codice_turno
		join dipendente on dipendente = matricola_dipendente
		join cinema on cinema = nome_cinema
		where tipo = 'maschera' and week(data_turno) = var_nr_settimana and (orario_inizio=orario_apertura or orario_fine=orario_chiusura)

		group by cinema,data_turno,orario_inizio,orario_fine
		having count(matricola_dipendente)<2
		order by cinema,data_turno, orario_inizio;
		
		select codice_spettacolo from `spettacolo`left outer join `servizio` on proiezionista = dipendente
		where proiezionista is null and week(data_spettacolo) = var_nr_settimana;
		 
    
    commit;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure verifica_prenotazione
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`verifica_prenotazione`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `verifica_prenotazione`(in var_codice_di_prenotazione int)
BEGIN

    declare var_esito_verifica enum('utilizzata','inutilizzata','annullata');
    declare var_data date;
    
    declare exit handler for sqlexception
    begin
        rollback;  -- rollback any changes made in the transaction
        resignal;  -- raise again the sql exception to the caller
    end;
    
    set transaction isolation level read committed; 
	start transaction;
    
		if var_codice_di_prenotazione not in (select codice_prenotazione from `prenotazione`) then
		  signal sqlstate '45001' set message_text = "Prenotazione non presente nel sistema!";
		end if;
		
		select data_spettacolo, esito from `prenotazione` join `spettacolo` on spettacolo_prenotato = codice_spettacolo
        where codice_prenotazione = var_codice_di_prenotazione into var_data, var_esito_verifica;
		
		if var_data <> curdate() then
			signal sqlstate '45001' set message_text = "Non è possibile accedere al cinema! La prenotazione non è relativa alla data odierna.";
		end if;
		
		if var_esito_verifica = 'inutilizzata' then
			update `prenotazione` set esito = 'utilizzata' where codice_prenotazione = var_codice_di_prenotazione;
		elseif var_esito_verifica = 'annullata' then
			signal sqlstate '45001' set message_text = "Non è possibile accedere al cinema! La prenotazione è stata annullata";
		else 
			signal sqlstate '45001' set message_text = "Non è possibile accedere di nuovo al cinema! Prenotazione già utilizzata.";
		end if;
		
    commit;
    
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure visualizza_dipendenti
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`visualizza_dipendenti`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `visualizza_dipendenti`()
BEGIN

		SELECT * FROM Gestione_cinema.dipendente;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure visualizza_posti_disponibili_per_spettacolo
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`visualizza_posti_disponibili_per_spettacolo`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `visualizza_posti_disponibili_per_spettacolo`(IN var_spettacolo INT)
BEGIN
	declare var_sala smallint;
    declare var_cinema varchar(45);
    
    declare exit handler for sqlexception
		begin
			rollback;  -- rollback any changes made in the transaction
			resignal;  -- raise again the sql exception to the caller
		end;
		
       
	set transaction isolation level repeatable read; 
	start transaction;
       
       select sala_spettacolo, cinema 
       from `spettacolo` 
       where codice_spettacolo = var_spettacolo into var_sala,var_cinema;
       
       select numero_posto,fila 
       from `posto` 
       where sala = var_sala and cinema = var_cinema and (numero_posto,fila,sala,cinema) not in (select nr_posto,fila_posto,nr_sala,prenotazione.cinema
																								from prenotazione
																								where spettacolo_prenotato = var_spettacolo);
     commit;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure visualizza_prenotazioni_attive
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`visualizza_prenotazioni_attive`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `visualizza_prenotazioni_attive`(in var_username varchar (45))
BEGIN
declare exit handler for sqlexception
		begin
			rollback;  -- rollback any changes made in the transaction
			resignal;  -- raise again the sql exception to the caller
		end;
    
	set transaction isolation level repeatable read; 
	start transaction;
    
		select codice_prenotazione, esito,nome_film,data_spettacolo,nr_posto,fila_posto,nr_sala,prenotazione.cinema
		from Gestione_cinema.prenotazione join Gestione_cinema.cliente on cliente_associato = codice_cliente
		join Gestione_cinema.spettacolo on spettacolo_prenotato = codice_spettacolo
		join Gestione_cinema.film on film = codice_film
		where username_cliente = var_username and esito = "inutilizzata" and data_spettacolo >= current_date() ;
		
	commit;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure visualizza_prezzo_orario_sala
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`visualizza_prezzo_orario_sala`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `visualizza_prezzo_orario_sala`()
BEGIN

	declare exit handler for sqlexception
		begin
			rollback;  -- rollback any changes made in the transaction
			resignal;  -- raise again the sql exception to the caller
		end;
        
	set transaction isolation level read uncommitted; 
	start transaction;
    
	SELECT * FROM Gestione_cinema.prezzo_spettacolo;
    
    commit;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure visualizza_spettacoli_prenotabili
-- -----------------------------------------------------

USE `Gestione_cinema`;
DROP procedure IF EXISTS `Gestione_cinema`.`visualizza_spettacoli_prenotabili`;

DELIMITER $$
USE `Gestione_cinema`$$
CREATE PROCEDURE `visualizza_spettacoli_prenotabili`()
BEGIN

	declare exit handler for sqlexception
		begin
			rollback;  -- rollback any changes made in the transaction
			resignal;  -- raise again the sql exception to the caller
		end;
    
	set transaction isolation level read committed; 
	start transaction;
    
		select codice_spettacolo, data_spettacolo,ora_spettacolo, nome_film, sala_spettacolo, cinema, prezzo
		from `spettacolo` join `film` on film = codice_film and data_spettacolo >= current_date() 
            join `prezzo_spettacolo` on sala_prezzo = sala_spettacolo and ora_prezzo = ora_spettacolo
		    order by data_spettacolo;
	commit;
END$$

DELIMITER ;
SET SQL_MODE = '';
DROP USER IF EXISTS login;
SET SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';
CREATE USER 'login' IDENTIFIED BY 'loginlogin';

GRANT EXECUTE ON procedure `Gestione_cinema`.`login` TO 'login';
SET SQL_MODE = '';
DROP USER IF EXISTS cliente;
SET SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';
CREATE USER 'cliente' IDENTIFIED BY 'clientecliente';

GRANT EXECUTE ON procedure `Gestione_cinema`.`visualizza_prenotazioni_attive` TO 'cliente';
GRANT EXECUTE ON procedure `Gestione_cinema`.`prenota_spettacolo` TO 'cliente';
GRANT EXECUTE ON procedure `Gestione_cinema`.`annulla_prenotazione` TO 'cliente';
GRANT EXECUTE ON procedure `Gestione_cinema`.`inserisci_carta_di_credito` TO 'cliente';
GRANT EXECUTE ON procedure `Gestione_cinema`.`visualizza_posti_disponibili_per_spettacolo` TO 'cliente';
GRANT EXECUTE ON procedure `Gestione_cinema`.`visualizza_spettacoli_prenotabili` TO 'cliente';
SET SQL_MODE = '';
DROP USER IF EXISTS maschera;
SET SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';
CREATE USER 'maschera' IDENTIFIED BY 'mascheramaschera';

GRANT EXECUTE ON procedure `Gestione_cinema`.`verifica_prenotazione` TO 'maschera';
SET SQL_MODE = '';
DROP USER IF EXISTS amministratore;
SET SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';
CREATE USER 'amministratore' IDENTIFIED BY 'amministratore';

GRANT EXECUTE ON procedure `Gestione_cinema`.`assegna_turno_di_lavoro` TO 'amministratore';
GRANT EXECUTE ON procedure `Gestione_cinema`.`inserisci_dipendente` TO 'amministratore';
GRANT EXECUTE ON procedure `Gestione_cinema`.`report_mensile_prenotazioni` TO 'amministratore';
GRANT EXECUTE ON procedure `Gestione_cinema`.`aggiungi_cliente` TO 'amministratore';
GRANT EXECUTE ON procedure `Gestione_cinema`.`crea_utente` TO 'amministratore';
GRANT EXECUTE ON procedure `Gestione_cinema`.`inserisci_film` TO 'amministratore';
GRANT EXECUTE ON procedure `Gestione_cinema`.`report_settimanale_turni` TO 'amministratore';
GRANT EXECUTE ON procedure `Gestione_cinema`.`visualizza_dipendenti` TO 'amministratore';
GRANT EXECUTE ON procedure `Gestione_cinema`.`visualizza_prezzo_orario_sala` TO 'amministratore';
GRANT EXECUTE ON procedure `Gestione_cinema`.`inserisci_spettacolo` TO 'amministratore';
GRANT EXECUTE ON procedure `Gestione_cinema`.`registra_turno_di_lavoro` TO 'amministratore';

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- begin attached script 'script'
CREATE EVENT IF NOT EXISTS `prenotazione_evento`
on schedule every 10 minute
on completion preserve 
do 
	delete from Gestione_cinema.prenotazione
    where esito = 'in processamento' and ora_prenotazione < date_sub(curtime(),interval 10 minute);
-- end attached script 'script'

-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`utenti`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`utenti` (`username`, `password`, `ruolo`) VALUES ('marina', 'ce5225d01c39d2567bc229501d9e610d', 'amministratore');
INSERT INTO `Gestione_cinema`.`utenti` (`username`, `password`, `ruolo`) VALUES ('cristian', 'b08c8c585b6d67164c163767076445d6', 'maschera');
INSERT INTO `Gestione_cinema`.`utenti` (`username`, `password`, `ruolo`) VALUES ('lilia', 'e5b5a57b9d168fbdd42a1e8799dd59c3', 'cliente');
INSERT INTO `Gestione_cinema`.`utenti` (`username`, `password`, `ruolo`) VALUES ('valerio', '7d9644c560a8e85d9e53265ef4739927', 'cliente');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`cliente`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`cliente` (`codice_cliente`, `username_cliente`) VALUES (01, 'lilia');
INSERT INTO `Gestione_cinema`.`cliente` (`codice_cliente`, `username_cliente`) VALUES (02, 'valerio');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`carta_di_credito`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`carta_di_credito` (`numero_carta`, `cliente`, `nome_intestatario`, `data_scadenza_carta`, `cvv`) VALUES (435678907345, 01, 'lilia c', '2022-09-24', 234);
INSERT INTO `Gestione_cinema`.`carta_di_credito` (`numero_carta`, `cliente`, `nome_intestatario`, `data_scadenza_carta`, `cvv`) VALUES (234786255342, 02, 'valerio c', '2022-09-12', 123);

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`film`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`film` (`codice_film`, `nome_film`, `casa_cinematografica`, `durata`) VALUES (01, 'alcarras', 'wonder pictures', 120);
INSERT INTO `Gestione_cinema`.`film` (`codice_film`, `nome_film`, `casa_cinematografica`, `durata`) VALUES (02, 'marcel', 'vision distribution', 93);
INSERT INTO `Gestione_cinema`.`film` (`codice_film`, `nome_film`, `casa_cinematografica`, `durata`) VALUES (03, 'nostalgia', 'medusa', 117);
INSERT INTO `Gestione_cinema`.`film` (`codice_film`, `nome_film`, `casa_cinematografica`, `durata`) VALUES (04, 'angelo dei muri', 'monet', 102);

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`cast_artistico`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`cast_artistico` (`nome_attore`, `cognome_attore`, `film`) VALUES ('albert', 'bosch', 01);
INSERT INTO `Gestione_cinema`.`cast_artistico` (`nome_attore`, `cognome_attore`, `film`) VALUES ('umberto', 'orsini', 02);
INSERT INTO `Gestione_cinema`.`cast_artistico` (`nome_attore`, `cognome_attore`, `film`) VALUES ('giovanna', 'ralli', 02);
INSERT INTO `Gestione_cinema`.`cast_artistico` (`nome_attore`, `cognome_attore`, `film`) VALUES ('tommaso', 'ragno', 03);
INSERT INTO `Gestione_cinema`.`cast_artistico` (`nome_attore`, `cognome_attore`, `film`) VALUES ('pierre', 'richard', 04);
INSERT INTO `Gestione_cinema`.`cast_artistico` (`nome_attore`, `cognome_attore`, `film`) VALUES ('gioia', 'heinz', 04);

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`cinema`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`cinema` (`nome_cinema`, `orario_apertura`, `orario_chiusura`) VALUES ('atlantico', '11:00', '23:00');
INSERT INTO `Gestione_cinema`.`cinema` (`nome_cinema`, `orario_apertura`, `orario_chiusura`) VALUES ('pacifico', '11:00', '23:00');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`dipendente`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dm01', 'pietro', 'verdi', 'maschera', 'atlantico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dm02', 'daniele', 'rossi', 'maschera', 'atlantico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dm03', 'isabel', 'bianchi', 'maschera', 'atlantico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dm04', 'cristian', 'neri', 'maschera', 'atlantico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dm05', 'livia', 'rosa', 'maschera', 'pacifico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dm06', 'gabriele', 'marroni', 'maschera', 'pacifico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dm07', 'mirko', 'gialli', 'maschera', 'pacifico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dp01', 'monica', 'viola', 'proiezionista', 'atlantico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dp02', 'giulio', 'grigio', 'proiezionista', 'atlantico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dp03', 'arianna', 'blu', 'proiezionista', 'atlantico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dp04', 'matteo', 'arancione', 'proiezionista', 'pacifico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dp05', 'simone', 'lilla', 'proiezionista', 'pacifico');
INSERT INTO `Gestione_cinema`.`dipendente` (`matricola_dipendente`, `nome_dipendente`, `cognome_dipendente`, `tipo`, `cinema`) VALUES ('dp06', 'cassandra', 'celeste', 'proiezionista', 'pacifico');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`posto`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (1, 'A', 1, 'atlantico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (2, 'A', 1, 'atlantico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (3, 'A', 1, 'atlantico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (1, 'A', 1, 'pacifico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (2, 'A', 1, 'pacifico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (3, 'A', 1, 'pacifico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (1, 'A', 2, 'atlantico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (2, 'A', 2, 'atlantico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (1, 'B', 2, 'atlantico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (2, 'B', 2, 'atlantico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (1, 'A', 2, 'pacifico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (1, 'B', 2, 'pacifico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (2, 'A', 2, 'pacifico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (2, 'B', 2, 'pacifico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (1, 'B', 1, 'atlantico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (2, 'B', 1, 'atlantico');
INSERT INTO `Gestione_cinema`.`posto` (`numero_posto`, `fila`, `sala`, `cinema`) VALUES (3, 'B', 1, 'atlantico');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`prezzo_spettacolo`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`prezzo_spettacolo` (`sala_prezzo`, `ora_prezzo`, `prezzo`) VALUES (1, '12:00', 3);
INSERT INTO `Gestione_cinema`.`prezzo_spettacolo` (`sala_prezzo`, `ora_prezzo`, `prezzo`) VALUES (1, '15:00', 4);
INSERT INTO `Gestione_cinema`.`prezzo_spettacolo` (`sala_prezzo`, `ora_prezzo`, `prezzo`) VALUES (1, '18:00', 5);
INSERT INTO `Gestione_cinema`.`prezzo_spettacolo` (`sala_prezzo`, `ora_prezzo`, `prezzo`) VALUES (1, '21:00', 8);
INSERT INTO `Gestione_cinema`.`prezzo_spettacolo` (`sala_prezzo`, `ora_prezzo`, `prezzo`) VALUES (2, '16:00', 6);
INSERT INTO `Gestione_cinema`.`prezzo_spettacolo` (`sala_prezzo`, `ora_prezzo`, `prezzo`) VALUES (2, '20:00', 7);

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`spettacolo`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`spettacolo` (`codice_spettacolo`, `data_spettacolo`, `ora_spettacolo`, `film`, `sala_spettacolo`, `cinema`, `proiezionista`) VALUES (01, '2022-06-24', '15:00', 01, 1, 'atlantico', 'dp03');
INSERT INTO `Gestione_cinema`.`spettacolo` (`codice_spettacolo`, `data_spettacolo`, `ora_spettacolo`, `film`, `sala_spettacolo`, `cinema`, `proiezionista`) VALUES (02, '2022-06-24', '18:00', 02, 1, 'atlantico', NULL);
INSERT INTO `Gestione_cinema`.`spettacolo` (`codice_spettacolo`, `data_spettacolo`, `ora_spettacolo`, `film`, `sala_spettacolo`, `cinema`, `proiezionista`) VALUES (03, '2022-06-24', '21:00', 04, 1, 'atlantico', NULL);
INSERT INTO `Gestione_cinema`.`spettacolo` (`codice_spettacolo`, `data_spettacolo`, `ora_spettacolo`, `film`, `sala_spettacolo`, `cinema`, `proiezionista`) VALUES (04, '2022-06-24', '20:00', 01, 2, 'atlantico', NULL);
INSERT INTO `Gestione_cinema`.`spettacolo` (`codice_spettacolo`, `data_spettacolo`, `ora_spettacolo`, `film`, `sala_spettacolo`, `cinema`, `proiezionista`) VALUES (05, '2022-06-24', '12:00', 02, 1, 'pacifico', 'dp05');
INSERT INTO `Gestione_cinema`.`spettacolo` (`codice_spettacolo`, `data_spettacolo`, `ora_spettacolo`, `film`, `sala_spettacolo`, `cinema`, `proiezionista`) VALUES (06, '2022-06-25', '18:00', 03, 1, 'pacifico', 'dp04');
INSERT INTO `Gestione_cinema`.`spettacolo` (`codice_spettacolo`, `data_spettacolo`, `ora_spettacolo`, `film`, `sala_spettacolo`, `cinema`, `proiezionista`) VALUES (07, '2022-06-25', '20:00', 03, 2, 'pacifico', NULL);
INSERT INTO `Gestione_cinema`.`spettacolo` (`codice_spettacolo`, `data_spettacolo`, `ora_spettacolo`, `film`, `sala_spettacolo`, `cinema`, `proiezionista`) VALUES (08, '2022-06-20', '21:00', 04, 1, 'pacifico', NULL);

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`prenotazione`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`prenotazione` (`codice_prenotazione`, `data_prenotazione`, `ora_prenotazione`, `esito`, `spettacolo_prenotato`, `nr_posto`, `fila_posto`, `nr_sala`, `cinema`, `cliente_associato`) VALUES (01, '2022-06-22', '18:00', 'inutilizzata', 01, 1, 'B', 1, 'atlantico', 01);
INSERT INTO `Gestione_cinema`.`prenotazione` (`codice_prenotazione`, `data_prenotazione`, `ora_prenotazione`, `esito`, `spettacolo_prenotato`, `nr_posto`, `fila_posto`, `nr_sala`, `cinema`, `cliente_associato`) VALUES (02, '2022-06-20', '13:00', 'inutilizzata', 06, 2, 'A', 1, 'atlantico', 01);
INSERT INTO `Gestione_cinema`.`prenotazione` (`codice_prenotazione`, `data_prenotazione`, `ora_prenotazione`, `esito`, `spettacolo_prenotato`, `nr_posto`, `fila_posto`, `nr_sala`, `cinema`, `cliente_associato`) VALUES (04, '2022-06-17', '14:00', 'utilizzata', 08, 1, 'A', 1, 'pacifico', 01);
INSERT INTO `Gestione_cinema`.`prenotazione` (`codice_prenotazione`, `data_prenotazione`, `ora_prenotazione`, `esito`, `spettacolo_prenotato`, `nr_posto`, `fila_posto`, `nr_sala`, `cinema`, `cliente_associato`) VALUES (05, '2022-06-19', '20:00', 'inutilizzata', 06, 1, 'A', 1, 'atlantico', 02);
INSERT INTO `Gestione_cinema`.`prenotazione` (`codice_prenotazione`, `data_prenotazione`, `ora_prenotazione`, `esito`, `spettacolo_prenotato`, `nr_posto`, `fila_posto`, `nr_sala`, `cinema`, `cliente_associato`) VALUES (06, '2022-06-20', '11:00', 'inutilizzata', 05, 3, 'A', 1, 'pacifico', 02);

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`sala`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`sala` (`numero_sala`, `cinema`) VALUES (1, 'atlantico');
INSERT INTO `Gestione_cinema`.`sala` (`numero_sala`, `cinema`) VALUES (2, 'atlantico');
INSERT INTO `Gestione_cinema`.`sala` (`numero_sala`, `cinema`) VALUES (1, 'pacifico');
INSERT INTO `Gestione_cinema`.`sala` (`numero_sala`, `cinema`) VALUES (2, 'pacifico');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`turno_lavoro`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`turno_lavoro` (`codice_turno`, `data_turno`, `orario_inizio`, `orario_fine`) VALUES (01, '2022-06-24', '11:00', '16:00');
INSERT INTO `Gestione_cinema`.`turno_lavoro` (`codice_turno`, `data_turno`, `orario_inizio`, `orario_fine`) VALUES (02, '2022-06-24', '16:00', '23:00');
INSERT INTO `Gestione_cinema`.`turno_lavoro` (`codice_turno`, `data_turno`, `orario_inizio`, `orario_fine`) VALUES (03, '2022-06-25', '11:00', '18:00');
INSERT INTO `Gestione_cinema`.`turno_lavoro` (`codice_turno`, `data_turno`, `orario_inizio`, `orario_fine`) VALUES (04, '2022-06-25', '18:00', '23:00');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Gestione_cinema`.`servizio`
-- -----------------------------------------------------
START TRANSACTION;
USE `Gestione_cinema`;
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dm01', 01, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dm02', 01, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dm05', 01, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dp03', 01, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dp05', 01, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dm04', 02, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dm07', 02, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dp06', 02, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dm03', 03, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dm06', 03, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dp01', 03, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dp03', 03, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dm01', 04, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dm07', 04, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dp04', 04, 25);
INSERT INTO `Gestione_cinema`.`servizio` (`dipendente`, `turno_di_lavoro`, `nr_settimana`) VALUES ('dp02', 04, 25);

COMMIT;

USE `Gestione_cinema`;

DELIMITER $$

USE `Gestione_cinema`$$
DROP TRIGGER IF EXISTS `Gestione_cinema`.`durata_turno` $$
USE `Gestione_cinema`$$
CREATE TRIGGER `Gestione_cinema`.`durata_turno`
BEFORE INSERT ON `Gestione_cinema`.`turno_lavoro`
FOR EACH ROW
BEGIN
  if timediff(new.orario_fine,new.orario_inizio)>"08:00:00" then
    signal sqlstate '45000' set message_text="La durata del turno non deve superare le 8 ore lavorative!";
  end if;
  
END$$


DELIMITER ;
